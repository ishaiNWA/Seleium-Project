

class TestData:
  
    forms = {
    "first_name": "ROBERTO",
    "last_name": "CARLOS",
    "email": "REALMADRID@gmail.com",
    "phone_number" : "7400011114"
    }





